let header = new Vue({
        el: '#town-header',
        data: {
            loginStatus: '登录',
            disabled: '',
            successVisible: 'invisible',
            dangerVisible: 'invisible',
            successInfo: '',
            dangerInfo: '',
            eventPath: ''
        },
        beforeCreate() {},
        created() {
            this.load()
        },
        methods: {
            hide: function (timeout) {
                setTimeout(() => {
                    this.successVisible = 'invisible';
                    this.dangerVisible = 'invisible';
                }, timeout);

            },
            close: function () {
                this.successVisible = 'invisible';
                this.dangerVisible = 'invisible';
            },
            load: function () {
                let path = window.location.pathname;
                if (path == '/login.html') {
                    this.dangerVisible = '';
                    this.dangerInfo = '请先登录';
                    this.hide(2500);
                    return;
                } else if (path != '/index.html') {
                    this.loginStatus = '已登录';
                    this.disabled = 'disabled';
                } else {
                    axios
                    .post(DOMAIN + "/user/isLogin")
                    .then(function (response) {
                        if (response.data.data == true) {
                            header.loginStatus = '已登录';
                            header.disabled = 'disabled';
                            return;
                        }
                    })
                }
            },
            valideLogin: function (e) {
                this.eventPath = e.target.pathname;
                e.preventDefault();
                axios
                .post(DOMAIN + "/user/isLogin")
                .then(function (response) {
                    if (response.data.data == true) {
                        if (header.eventPath == '/login.html') {
                            header.loginStatus = '已登录';
                            header.disabled = 'disabled';
                            return;
                        }
                        window.location.href = '..' + header.eventPath;
                    } else {
                        let path = header.eventPath;
                        if (path != '/index.html') {
                            window.location.href = '../login.html';
                        }
                    }
                })
                .catch(function (e) {
                    header.dangerVisible = '';
                    header.dangerInfo = e;
                    header.hide(2500);
                })
            }
        }
    });
