let productShow = new Vue({
        el: '#customer-style',
        data: {
            defaultStyle: ''
        },
        created: function () {
            axios
            .post(DOMAIN + "/user/getUserId")
            .then(function (response) {
                productShow.defaultStyle = '../customer/customer-product.html?userId=' + response.data.data;
            })
        }
    });
