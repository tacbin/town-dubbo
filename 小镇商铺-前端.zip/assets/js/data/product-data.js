let productDate = new Vue({
        el: '#product-data',
        created: function () {
            this.loadLastTenProduct();
            this.loadTodaytenProducts();
			this.loadViewerOfChina();
        },
        methods: {
            loadLastTenProduct: function () {
                axios
                .post(DOMAIN + "/productData/lastTenProducts")
                .then(function (response) {
                    let chart = document.querySelector('#lastTenproducts canvas').chart;
                    for (let i = 0; i < response.data.data.length; i++) {
                        chart.config.data.labels.push(response.data.data[i].name + "");
                        chart.config.data.datasets[0].data.push(response.data.data[i].viewCount + "")
                    }
                    chart.update();
                })
            },
            loadTodaytenProducts: function () {
                axios
                .post(DOMAIN + "/productData/todayTenProducts")
                .then(function (response) {
                    let chart = document.querySelector('#todayProducts canvas').chart;
                    for (let i = 0; i < response.data.data.length; i++) {
                        chart.config.data.labels.push(response.data.data[i].name + "");
                        chart.config.data.datasets[0].data.push(response.data.data[i].viewCount + "")
                    }
                    chart.update();
                })
            },
            loadViewerOfChina: function () {
                axios
                .post(DOMAIN + "/productData/viewerOfChina")
                .then(function (response) {
                    let chart = document.querySelector('#viewerOfChina canvas').chart;
                    for (let i = 0; i < response.data.data.length; i++) {
                        chart.config.data.labels.push(response.data.data[i].location + "");
                        chart.config.data.datasets[0].data.push(response.data.data[i].locationCount + "")
                    }
                    chart.update();
                })
            }
        }
    });
