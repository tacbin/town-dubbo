let newModal = new Vue({
        el: "#new-modal",
        data: {
            name: '',
            queue: '50',
        },
        methods: {
            checkForm: function (e) {
                e.preventDefault() // 阻止默认提交
                let param = new URLSearchParams();
                param.append('name', this.name);
                param.append('queue', this.queue);
                axios
                .post(DOMAIN + "/category/create", param)
                .then(function (response) {
                    if (response.data.status == "SUCCESS") {
                        leftCategory.categories.push(response.data.data);
                        $('#new-modal').modal('hide');
                        header.successVisible = '';
                        header.successInfo = "新增成功";
                    } else {
                        header.dangerVisible = '';
                        header.dangerInfo = response.data.message;
                    }
                    header.hide(3000);
                    $('#new-modal').modal('hide');
                    newModal.name = ''
                })
            }
        }
    });

let editModal = new Vue({
        el: '#edit-modal',
        data: {
            oldName: '',
            newName: '',
            categories: [],
            queue: ''
        },
        created() {
            this.getCategories()
        },
        methods: {
            checkForm: function (e) {
                e.preventDefault();
                // 查询数据
                let param = new URLSearchParams();
                param.append('oldName', this.oldName);
                if (this.newName.length > 0) {
                    param.append('newName', this.newName);
                }
                if (this.queue.length > 0) {
                    param.append('queue', this.queue);
                } else {
                    param.append('queue', '-1');
                }
                axios
                .post(DOMAIN + "/category/changeName", param)
                .then(function (response) {
                    leftCategory.queryData();
                    header.successVisible = '';
                    header.successInfo = "修改成功";
                    header.hide(1500);
                    editModal.newName = '';
                    editModal.queue = '';
                    $('#edit-modal').modal('hide');
                })
            },
            getCategories: function () {
                // 查询数据
                axios
                .post(DOMAIN + "/category/getAll")
                .then(function (response) {
                    editModal.categories = response.data.data;
                })
            }
        }
    });

let delModal = new Vue({
        el: '#del-modal',
        data: {
            name: '',
            categories: []
        },
        created() {
            this.getCategories()
        },
        methods: {
            checkForm: function (e) {
                e.preventDefault();
                // 删除目录
                let param = new URLSearchParams();
                param.append('name', this.name);
                axios
                .post(DOMAIN + "/category/delete", param)
                .then(function (response) {
                    if (response.data.status == "SUCCESS") {
                        leftCategory.queryData();
                        header.successVisible = '';
                        header.successInfo = "删除成功";
                    } else {
                        header.dangerVisible = '';
                        header.dangerInfo = response.data.message;
                    }
                    header.hide(1500);
                    $('#del-modal').modal('hide');
                    delModal.name = ''
                })
            },
            getCategories: function () {
                // 查询数据
                axios
                .post(DOMAIN + "/category/getAll")
                .then(function (response) {
                    delModal.categories = response.data.data;
                })
            }
        }
    });

let newProduct = new Vue({
        el: '#new-product-modal',
        data: {
            name: '',
            price: '',
            description: '',
            enable: true,
            fileUrl: '',
            file0: '',
            file1: '',
            file2: '',
            categories: [],
            categoryId: '',
            queue: '50'
        },
        created() {
            this.getCategories()
        },
        methods: {
            checkForm: function (e) {
                e.preventDefault();
                let param = new URLSearchParams();
                param.append('name', this.name);
                param.append('price', this.price);
                param.append('description', this.description);
                if (this.enable) {
                    param.append('enable', '1');
                } else {
                    param.append('enable', '0');
                };
                param.append('categoryId', this.categoryId);
                param.append('queue', this.queue);
                param.append('img1', this.fileUrl);
                param.append('img2', this.file0);
                param.append('img3', this.file1);
                axios.post(DOMAIN + "/product/addProduct", param).then(function (res) {
                    product.queryAndWrapProduct(leftCategory.currentIndex);
                    $('#new-product-modal').modal('hide');
                    newProduct.name = '';
                    newProduct.price = '';
                    newProduct.description = '';
                    newProduct.enable = true;
                    newProduct.fileUrl = '';
                    newProduct.file0 = '';
                    newProduct.file1 = '';
                    newProduct.file2 = '';
                    newProduct.categoryId = '';
                    newProduct.queue = '0';
                    document.getElementById('newProductForm').reset();
                })
            },
            sigleSelected: function (e) {
                if (e.target.files[0].size / 1024 / 1024 > 15) {
                    $('#new-product-modal').modal('hide');
                    header.dangerVisible = '';
                    header.dangerInfo = '图片太大了，大于15M。请压缩图片再上传或换图片';
                    header.hide(5000);
                    document.getElementById('newProductForm').reset();
                    return;
                }
                let form = new FormData();
                form.append('file', e.target.files[0]);
                axios.post(DOMAIN + "/files/oneImageUpload", form, {
                    'Content-Type': 'multipart/form-data;charset=UTF-8'
                }).then(function (res) {
                    newProduct.fileUrl = res.data.data;
                })
            },
            afterSelected: function (e) {
                if (e.target.files.length > 2) {
                    let images = document.getElementById('images');
                    images.value = '';
                    $('#new-product-modal').modal('hide');
                    header.dangerVisible = '';
                    header.dangerInfo = '图片数量不能超过3张';
                    header.hide(5000);
                    document.getElementById('newProductForm').reset();
                    return;
                } else {
                    let form = new FormData();
                    form.append('file0', e.target.files[0]);
                    form.append('file1', e.target.files[1]);
                    let headers = {
                        'Content-Type': 'multipart/form-data'
                    }
                    axios.post(DOMAIN + "/files/twoImagesUpload", form, {
                        headers: headers
                    }).then(function (res) {
                        if (res.data.data != null) {
                            newProduct.file0 = res.data.data[0];
                            newProduct.file1 = res.data.data[1];
                        }
                    })
                }
            },
            getCategories: function () {
                // 查询数据
                axios
                .post(DOMAIN + "/category/getAll")
                .then(function (response) {
                    newProduct.categories = response.data.data;
                })
            }
        }
    });

let editProduct = new Vue({
        el: '#edit-product-modal',
        data: {
            id: '',
            name: '',
            price: '',
            description: '',
            enable: true,
            fileUrl: '',
            file0: '',
            file1: '',
            file2: '',
            categories: [],
            categoryId: '',
            queue: ''
        },
        created() {
            this.getCategories()
        },
        methods: {
            checkForm: function (e) {
                e.preventDefault();
                let param = new URLSearchParams();
                param.append('name', this.name);
                param.append('price', this.price);
                param.append('description', this.description);
                if (this.enable) {
                    param.append('enable', '1');
                } else {
                    param.append('enable', '0');
                };
                param.append('categoryId', this.categoryId);
                param.append('img1', this.fileUrl);
                param.append('img2', this.file0);
                param.append('img3', this.file1);
                param.append('id', this.id);
                param.append('queue', this.queue);
                axios.post(DOMAIN + "/product/updateProduct", param).then(function (res) {
                    $('#edit-product-modal').modal('hide');
                    product.queryAndWrapProduct(leftCategory.currentIndex);
                    editProduct.name = '';
                    editProduct.price = '';
                    editProduct.description = '';
                    editProduct.enable = true;
                    editProduct.fileUrl = '';
                    editProduct.file0 = '';
                    editProduct.file1 = '';
                    editProduct.file2 = '';
                    editProduct.categoryId = '';
                    editProduct.id = '';
                    editProduct.queue = '';
                })
            },
            sigleSelected: function (e) {
                if (e.target.files[0].size / 1024 / 1024 > 15) {
                    $('#new-product-modal').modal('hide');
                    header.dangerVisible = '';
                    header.dangerInfo = '图片太大了，大于15M请压缩图片再上传或换图片';
                    header.hide(1500);
                    return;
                }
                let form = new FormData();
                form.append('file', e.target.files[0]);
                axios.post(DOMAIN + "/files/oneImageUpload", form, {
                    'Content-Type': 'multipart/form-data;charset=UTF-8'
                }).then(function (res) {
                    editProduct.fileUrl = res.data.data;
                })
            },
            afterSelected: function (e) {
                if (e.target.files.length > 2) {
                    let images = document.getElementById('images');
                    images.value = '';
                    $('#new-product-modal').modal('hide');
                    header.dangerVisible = '';
                    header.dangerInfo = '图片数量不能超过3张';
                    header.hide(1500);
                } else {
                    let form = new FormData();
                    form.append('file0', e.target.files[0]);
                    form.append('file1', e.target.files[1]);
                    axios.post(DOMAIN + "/files/twoImagesUpload", form, {
                        'Content-Type': 'multipart/form-data;charset=UTF-8'
                    }).then(function (res) {
                        if (res.data.data != null) {
                            editProduct.file0 = res.data.data[0];
                            editProduct.file1 = res.data.data[1];
                        }
                    })
                }
            },
            getCategories: function () {
                // 查询数据
                axios
                .post(DOMAIN + "/category/getAll")
                .then(function (response) {
                    editProduct.categories = response.data.data;
                })
            }
        }
    });

let deleteModal = new Vue({
        el: '#do-delete-modal',
        data: {
            deleteId: '',
            categoryId: ''
        },
        methods: {
            doDelete: function () {
                let param = new URLSearchParams();
                param.append('productId', deleteModal.deleteId);
                axios
                .post(DOMAIN + "/product/deleteProduct", param)
                .then(function (response) {
                    product.queryAndWrapProduct(deleteModal.categoryId);
                });
            }
        }
    });
