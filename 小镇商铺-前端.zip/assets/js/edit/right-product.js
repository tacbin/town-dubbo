let product = new Vue({
        el: '#product-detail',
        data: {
            products: []
        },
        methods: {
            editProductEvent: function (e) {
                let productId = e.currentTarget.getAttribute('dataid');
                let param = new URLSearchParams();
                param.append('productId', productId);
                axios
                .post(DOMAIN + "/product/queryProductById", param)
                .then(function (response) {
                    document.getElementById('single-edit-file').value = '';
                    document.getElementById('multi-edit-file').value = '';
                    let product = response.data.data;
                    editProduct.name = product.name;
                    editProduct.price = product.price;
                    editProduct.description = product.description;
                    if (product.enable == '1') {
                        editProduct.enable = true;
                    } else {
                        editProduct.enable = false;
                    }
                    editProduct.categoryId = product.categoryId;
                    editProduct.fileUrl = product.img1;
                    editProduct.file0 = product.img2;
                    editProduct.file1 = product.img3;
                    editProduct.id = product.id;
                    editProduct.queue = product.queue;
                })
            },
            deleteProduct: function (e) {
                let productId = e.currentTarget.getAttribute('dataid');
                let categoryId = e.currentTarget.getAttribute('categoryid');
                deleteModal.deleteId = productId;
                deleteModal.categoryId = categoryId;
            },
            queryAndWrapProduct: function (categoryId) {
                // 查询目录下的商品
                let param = new URLSearchParams();
                param.append('categoryId', categoryId);
                axios
                .post(DOMAIN + "/product/queryProducts", param)
                .then(function (response) {
                    product.products = response.data.data;
                })
            }
        }
    })
