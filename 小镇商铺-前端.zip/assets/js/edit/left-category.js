let leftCategory = new Vue({
        el: '#left-category-id',
        data: {
            currentIndex: -1,
            categories: []
        },
        created() {
            this.queryData()
        },
        methods: {
            createOne: function (e) {
                // 点击商品目录
                let dataId = e.currentTarget.getAttribute('dataid');
                this.currentIndex = dataId;
                product.queryAndWrapProduct(dataId)
            },
            recommand: function () {
                // 点击商家推荐
            },
            queryData: function () {
                // 查询数据
                axios
                .post(DOMAIN + "/category/getAll")
                .then(function (response) {
                    leftCategory.categories = response.data.data;
                    if (response.data.data != null) {
                        let firstChild = response.data.data[0].id;
                        leftCategory.currentIndex = firstChild;
                        product.queryAndWrapProduct(firstChild);
                    }
                })
            }
        }
    })
