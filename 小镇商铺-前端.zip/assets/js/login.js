new Vue({
    el: '#login-form',
    data: {
        account: '',
        password: ''
    },
    methods: {
        checkForm: function (e) {
            e.preventDefault() // 阻止默认提交
            let param = new URLSearchParams();
            param.append('userName', this.account);
            param.append('password', this.password);
            axios
            .post(DOMAIN + "/user/login", param)
            .then(function (response) {
                if (response.data.status == 'SUCCESS') {
                    header.successVisible = '';
                    header.successInfo = response.data.message;
                    header.hide(1500);
                    window.location.href = '../index.html';
                } else {
                    header.dangerVisible = '';
                    header.dangerInfo = response.data.message;
                    header.hide(3000);
                }
            })
            .catch(function (e) {
                console.log(e);
            })
        }
    }
})
