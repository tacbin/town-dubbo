let customerDetail = new Vue({
        el: '#customer-product-detail',
        data: {
            product: ''
        },
        beforeCreate: function () {
            let param = new URLSearchParams();
            param.append('productId', getUrlParam('productId'));
            axios
            .post(DOMAIN + "/customer/product/queryProductById", param)
            .then(function (response) {
                customerDetail.product = response.data.data;
            })

        }
    })
