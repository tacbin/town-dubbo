let customerLeftCategory = new Vue({
        el: '#left-category-id',
        data: {
            currentIndex: -1,
            categories: []
        },
        created() {
            this.queryData()
        },
        methods: {
            createOne: function (e) {
                // 点击商品目录
                let dataId = e.currentTarget.getAttribute('dataid');
                this.currentIndex = dataId;
                customerProduct.queryAndWrapProduct(dataId)
            },
            recommand: function () {
                // 点击商家推荐
            },
            queryData: function () {
                let param = new URLSearchParams();
                param.append('userId', getUrlParam('userId'));
                // 查询数据
                axios
                .post(DOMAIN + "/customer/category/getAll", param)
                .then(function (response) {
                    customerLeftCategory.categories = response.data.data;
                    if (response.data.data != null) {
                        let firstChild = response.data.data[0].id;
                        customerLeftCategory.currentIndex = firstChild;
                        customerProduct.queryAndWrapProduct(firstChild);
                    }
                })
            }
        }
    });

let customerProduct = new Vue({
        el: '#product-detail',
        data: {
            products: []
        },
        methods: {
            queryAndWrapProduct: function (categoryId) {
                // 查询目录下的商品
                let param = new URLSearchParams();
                param.append('categoryId', categoryId);
                param.append('userId', getUrlParam('userId'));
                axios
                .post(DOMAIN + "/customer/product/queryProducts", param)
                .then(function (response) {
                    customerProduct.products = response.data.data;
                })
            },
            imgJump: function (e) {
                // 商品id
                let dataId = e.currentTarget.getAttribute('dataid');
                window.location.href = '../customer/customer-product-detail.html?productId=' + dataId + "&userId=" + getUrlParam('userId');
            }
        }
    });
